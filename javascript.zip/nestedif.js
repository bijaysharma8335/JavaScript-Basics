var a = "101Abc";
if(isNaN(a)){


console.log(a+"is string");
console.log("and length is :"+a.length);}
else{
	console.log(a+"is number");
	if(a%2==0)
	{
		console.log("Even No")
	}
	else{
		console.log("Odd No")
	}
}
