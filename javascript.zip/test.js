
//create a file tes,js
//write an if else where check condition
//if 50 is greater than 30 then multiply itself
//else add itself
 one = a =>
{
	if(a>30)
	{
		console.log("value is :"+a*a);
	}
else
	{
		console.log("value is:"+(a+a));
	}
}
one(50,30);
one(30,50);


var a=60;
if(a>30)
{
	console.log(a*a);
}
else{
	console.log(a+a);
}
