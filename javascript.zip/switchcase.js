console.log("Switch case Example");
var url="home.html";
switch(url)
{
	case "login.html": console.log("Display Home Page");
	break;
	case "home.html":
	console.log("Display Home Page");
	break;
	case "register.html":
	console.log("Display Register Page");
	break;
	default:console.log("Display Register Page");
} 