console.log("\n Javascript function example\n");
console.log(10+10);
console.log("\t How are You?");
console.log("The Addition of 10,20 is:"+ (10 + 20));
console.log("The *  of 10,20 is:"+ 10 * 20);
function Test()
{
    console.log("Hello Test");

}
Test();
