console.log("Hello Test");
var a=100;//int
var b=200.50;//float
var c="hello";//string,string:array
var d=true;//booloean
var e=false;//boolean
var f=[];//array
var g= new Array();//array
//var h =new Classname();//object of class
console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(e);
console.log(f.length);
console.log(g.length);