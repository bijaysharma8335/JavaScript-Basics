function one()
{
	console.log("From 1st method");
}
 var two=function()
{
	console.log("From 2nd method");
}
three = () => 
{
	console.log("From 3rd method");
}
//inline method
four=()=> console.log("from 4th method");
one();
two();
three();
four();

