console.log("----------------Do While Example");
var i=100;
do{
	console.log(i);
i++;
}
while(i<=10);


console.log("----------------------");
var i=100;

while(i<=10){
	console.log(a);
}